import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../components/Header';

const Dashboard = () => {
    const [sentiments, setSentiments] = useState([]);
    const [newSentiment, setNewSentiment] = useState('');
    const [userInfo, setUserInfo] = useState(null);
    const navigate = useNavigate();
    const token = localStorage.getItem('token');

    const fetchUserInfo = async () => {
        try {
            const userId = localStorage.getItem('userId');
            const response = await fetch(`http://localhost:8000/users/${userId}`, {
                headers: {
                    Authorization: `Bearer ${token}`,
                },
            });

            if (response.ok) {
                const data = await response.json();
                setUserInfo(data);
            } else {
                console.error('Failed to fetch user info');
            }
        } catch (error) {
            console.error('Error:', error);
        }
    };

    const fetchSentiments = async () => {
        try {
            const response = await fetch('http://localhost:8000/sentiments', {
                headers: {
                    Authorization: `Bearer ${token}`,
                },
            });

            if (response.ok) {
                const data = await response.json();
                setSentiments(data);
            } else if (response.status === 401) {
                navigate('/login');
            } else {
                console.error('Failed to fetch sentiments');
            }
        } catch (error) {
            console.error('Error:', error);
            navigate('/login');
        }
    };

    const handleCreateSentiment = async () => {
        if (!newSentiment.trim()) return;

        try {
            const response = await fetch('http://localhost:8000/sentiments', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${token}`,
                },
                body: JSON.stringify({ sentiments: newSentiment }),
            });

            if (response.ok) {
                setNewSentiment('');
                fetchSentiments();
            } else {
                console.error('Failed to create sentiment');
            }
        } catch (error) {
            console.error('Error:', error);
        }
    };

    useEffect(() => {
        if (!token) {
            navigate('/login');
            return;
        }
        fetchUserInfo();
        fetchSentiments();
    }, [navigate, token]);

    return (
        <>
            <Header userInfo={userInfo} />
            <div style={{
                minHeight: '100vh',
                width: '100vw',
                backgroundColor: '#1c1f2b',
                color: 'white',
                padding: '2rem',
                boxSizing: 'border-box',
                overflowY: 'auto'
            }}>
                <div style={{
                    maxWidth: '800px',
                    margin: '0 auto',
                    background: '#2b2f3e',
                    borderRadius: '12px',
                    padding: '2rem',
                    boxShadow: '0 4px 12px rgba(0,0,0,0.3)'
                }}>
                    <h2 style={{ textAlign: 'center', color: '#ff6f91' }}>📊 Your Sentiments</h2>

                    {sentiments.length === 0 ? (
                        <p>No sentiments recorded yet.</p>
                    ) : (
                        <ul style={{ listStyle: 'none', padding: 0 }}>
                            {sentiments.map((s) => (
                                <li
                                    key={s.id}
                                    style={{
                                        background: '#fff',
                                        color: '#333',
                                        margin: '1rem 0',
                                        padding: '1rem',
                                        borderRadius: '10px',
                                        boxShadow: '0 2px 6px rgba(0,0,0,0.1)'
                                    }}
                                >
                                    <strong>Sentiment:</strong> {s.sentiments} <br />
                                    <strong>Recommendation:</strong> {s.recommendation}
                                </li>
                            ))}
                        </ul>
                    )}

                    <div style={{ marginTop: '2rem' }}>
                        <h3 style={{ color: '#ffcd3c' }}>➕ Add New Sentiment</h3>
                        <textarea
                            rows="3"
                            style={{ width: '100%', padding: '0.75rem', borderRadius: '6px', fontSize: '1rem' }}
                            placeholder="Write your sentiment..."
                            value={newSentiment}
                            onChange={(e) => setNewSentiment(e.target.value)}
                        />
                        <button
                            onClick={handleCreateSentiment}
                            style={{
                                marginTop: '0.75rem',
                                padding: '0.75rem 1.5rem',
                                background: '#4caf50',
                                color: 'white',
                                border: 'none',
                                borderRadius: '6px',
                                fontSize: '1rem',
                                cursor: 'pointer',
                            }}
                        >
                            Submit
                        </button>
                    </div>

                    <button
                        onClick={() => {
                            localStorage.removeItem('token');
                            localStorage.removeItem('userId');
                            navigate('/login');
                        }}
                        style={{
                            marginTop: '2rem',
                            background: '#e74c3c',
                            color: 'white',
                            padding: '0.75rem 1.5rem',
                            border: 'none',
                            borderRadius: '6px',
                            fontSize: '1rem',
                            cursor: 'pointer',
                            display: 'block',
                            width: '100%'
                        }}
                    >
                        Logout
                    </button>
                </div>
            </div>
        </>
    );
};

export default Dashboard;
